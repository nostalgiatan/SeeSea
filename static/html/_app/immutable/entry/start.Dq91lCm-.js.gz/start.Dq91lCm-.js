import{l as o,d as r}from"../chunks/WRl8ndgg.js";export{o as load_css,r as start};
