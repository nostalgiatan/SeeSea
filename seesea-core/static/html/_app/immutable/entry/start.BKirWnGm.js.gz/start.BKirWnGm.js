import{l as o,d as r}from"../chunks/CVtFKUcV.js";export{o as load_css,r as start};
